# Requirements

### **Python Versions**
I explicitly called python2 to run both grading.py and master.py. Python 2 versions ran were 2.7.13 and 2.7.12, in case of problems on both of them, I usually run 2.7.13.

Python3 was used for my actual script running. Python 3 versions ran were 3.7.4 and 3.5.2, in case of problems on both of them, I usually run 3.7.4.

I had two main version as I routinely switched between running my programs on my local computers and sshing and then running my programs on remote machings.

