# ReadMe
Include documentation for course staff to run test cases.

### Slip Days

Slip days used (this project): 1 Slip days used (total): 1
### **Running**

python2 grading.py worked for running the grading protocol

python2 master.py worked for starting the script. Additionally, <,> could be used to feed data into the master script