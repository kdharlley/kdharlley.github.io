open Yojson.Basic.Util
open Types
open Attacks


(* Created a Pokedex using a dicitionary so pokemon could only be identified by their name.
   Used same implementation with attack. *)
type stats = {max_hp: int; current_hp: int; attack: int;
              defense: int; sp_attack:int; sp_def: int; speed: int;}

(* obtained from basic pokemon dataset *)
type pokemon = {
  name: string;
  poketype: elemtype;
  description: string;
  level : int;
  xp : int;
  attacks: string list ;
  stats:  stats;
}


let stats_json json = {
  max_hp = json |> member "HP" |> to_int;
  current_hp = json |> member "HP" |> to_int;
  attack = json |> member "Attack" |> to_int;
  defense = json |> member "Defense" |> to_int;
  sp_attack = json |> member "Sp. Attack" |> to_int;
  sp_def = json |> member "Sp. Defense" |> to_int;
  speed = json |> member "Speed" |> to_int;
}

let pokemon_from_json json = {
  name = json |> member "name" |> to_string;
  poketype = json |> member "type" |> to_string |> string_to_type ;
  description = json |> member "description" |> to_string ;
  stats = json |> member "base" |>  stats_json;
  level = 1;
  xp = 0;
  attacks = json |> member "attacks" |>  to_list |> List.map to_string;
}

let poke_list json =
  json |> to_list |> List.map pokemon_from_json

module PokemonMap = Map.Make (struct
    type t = string
    let compare = Stdlib.compare
  end
  )


let rec make_poke_dict p_lst pokedex =
  match p_lst with
  | [] -> pokedex
  | h::t -> make_poke_dict t PokemonMap.(add h.name h pokedex)


let pokedex json= make_poke_dict (poke_list json) PokemonMap.empty

type t = pokemon PokemonMap.t

let from_json json =
  pokedex json

let get_name (p:pokemon)=
  p.name

let get_atk (p:pokemon)=
  p.stats.attack

let get_type (p:pokemon)=
  p.poketype

let get_hp p =
  p.stats.current_hp

let get_max_hp p =
  p.stats.max_hp

let get_description p =
  p.description 

let level_up p =
  let new_stats = 
    {max_hp = p.stats.max_hp + 10;
     current_hp = p.stats.max_hp + 10; attack = p.stats.attack+10;
     defense = p.stats.defense+10; sp_attack = p.stats.sp_attack+10; 
     sp_def = p.stats.sp_def+10;  speed = p.stats.speed+10} in
  {p with stats =new_stats; level = p.level +1; xp =0}
(* failwith "Unimplementted" *)

let ready_to_level_up p =
  p.xp = 100
(* failwith "Unimplementted"; *)

let add_xp p x =
  {p with xp = p.xp +x}
(* failwith "Unimplementted" *)

let change_hp p h =
  let new_stats ={p.stats with current_hp = p.stats.current_hp + h} in
  {p with stats = new_stats}
(* failwith "Unimplementted" *)

let is_dead p =
  p.stats.current_hp <= 0

open PokemonMap

let rec pokemon_of_type_ext poke pokelist lst =
  match pokelist with
  | [] -> lst
  | (a, b)::t -> if b.poketype = (string_to_type poke) then begin
      pokemon_of_type_ext poke t (a::lst) 
    end else  pokemon_of_type_ext poke t lst


let rec pokemon_of_type (poke:string) (pokemap: pokemon PokemonMap.t) (lst:string list) = 
  (* PokemonMap.fold (fun k s p l -> if ((type_to_string k.poketype) == s) 
                    then (k::l) 
                    else (pokemon_of_type s (remove k p) l)) pokemap lst;; *)
  (* print_string poke; *)
  pokemon_of_type_ext poke (bindings pokemap) []
(* match bindings pokemap with *)

(* failwith "Unimplemented" *)

let get_pokemon pokedex p =
  let pokemon = find_opt p pokedex in
  match pokemon with
  | Some v -> v
  | None -> failwith "Pokemon Name not well-defined"

let get_desc p pokedex =
  let pokemon = get_pokemon pokedex p in
  pokemon.description 

