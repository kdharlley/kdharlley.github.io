type object_phrase = string list

type command = 
  | Go of object_phrase
  | Quit
  | Battle of object_phrase

exception Empty

exception Malformed

(** [remove_spaces str_list ongoing_list] is [str_list] with all elements 
    which are empty strings removed where [ongoing_list] is the computed value
    so far. *)
let rec remove_spaces str_list ongoing_list=
  match str_list with
  | [] -> List.rev ongoing_list
  | h::t -> 
    if h = "" then remove_spaces t ongoing_list else 
      remove_spaces t (h::ongoing_list)


(** [decision str_list] is the command represented by [str_list]
    Raises: [Empty] if [str_list] is the empty list or a list of empty strings
    Raises: [Malformed] if the command represented by [str_list]
     is malformed*)
let decision str_list = 
  let command_list = remove_spaces str_list [] in
  match command_list with
  | [] -> raise Empty
  | h::t -> 
    if h = "go" && List.length t > 0 then Go t else
    if h = "quit" && List.length t = 0 then Quit else
    if h = "battle" && List.length t > 0 then Battle t else
      raise Malformed

let parse str =
  decision (String.split_on_char ' ' str) 

