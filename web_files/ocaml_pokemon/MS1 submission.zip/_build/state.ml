open Pokemon
open Gameworld
type state = {current_room: string}

type t = {
  my_pokemon : pokemon;
  current_room: string;
  defeated_characters: string list;
  visited_rooms : string list;
  in_battle : bool;
}

let init_state (game) (pokedex) (poke: string)= {
  my_pokemon = get_pokemon pokedex poke ; 
  current_room = Gameworld.start_room game |> Gameworld.room_name; 
  defeated_characters = []; 
  visited_rooms = [start_room game |>room_name;];
  in_battle = false
}

let current_room st =
  st.current_room

let curr_pokemon st =
  st.my_pokemon

let def_charas st =
  st.defeated_characters

let visited_rooms st =
  st.visited_rooms

let in_battle st = 
  st.in_battle

let set_in_battle bool st ={
  my_pokemon = curr_pokemon st ; 
  current_room = current_room st;
  defeated_characters = def_charas st; 
  visited_rooms = visited_rooms st;
  in_battle = bool
}

type result = Legal of t | Illegal

let go s game st =
  try
    let rm_visit = room_to_visit game st.current_room s |> room_name in
    Legal {st with current_room = rm_visit ; visited_rooms = rm_visit::st.visited_rooms}
  with UnknownMovement s -> Illegal
(* let go ex game s =
     try
      let room_to_visit = get_room s game in
      if exit_status adv ex st.current_room then begin
        Legal { current_room = room_to_visit; 
                visited_rooms = (room_to_visit::st.visited_rooms); 
                inventory = st.inventory }
      end else Illegal
     with UnknownExit ex -> Illegal *)
