open Pokemon
open Yojson.Basic.Util
exception UnknownMovement of string

type character = {
  name: string;
  description: string;
  pokemon: pokemon;
}

let character_from_json pokedex json= {
  name = json |> member "name" |> to_string;
  description = json |> member "description" |> to_string ;
  pokemon = json |> member "pokemon" |> to_string |> Pokemon.get_pokemon pokedex ;
}

type room = {
  previous_room: string;
  description: string;
  name: string;
  characters: character list;
  next_room: string;
}

let room_from_json pokedex json= {
  previous_room = json |> member "previous_room" |> to_string;
  description = json |> member "description" |> to_string;
  next_room = json |> member "next_room" |> to_string;
  name = json |> member "name" |> to_string;
  characters = json |> member "characters" |> to_list |> List.map (character_from_json pokedex);
}

type game = {
  rooms: room list;
  description: string;
  start_room: string;
}

let game_json json pokedex = {
  rooms = json |> member "rooms" |> to_list |> List.map (room_from_json pokedex);
  description = json |> member "description" |> to_string;
  start_room = json |> member "start_room" |> to_string;
}

let rec get_rooms_ext s rms =
  match rms with
  | [] -> failwith "There should be a room"
  | h::t -> if h.name = s then h else get_rooms_ext s t

let  get_room game s =
  get_rooms_ext s game.rooms

let rec get_chars_ext s (chars:character list) = 
  match chars with
  | [] -> failwith "There is no character like that."
  | h::t -> if s=h.name then h else get_chars_ext s t

let get_char game  s=
  get_chars_ext s game.characters

let start_room game =
  let start_name = game.start_room in
  get_room game start_name 

let next_room game s =
  let rm = get_room game s  in
  get_room game rm.next_room

let prev_room game s =
  let rm = get_room game s  in
  get_room game rm.previous_room

let room_desc game s =
  let rm = get_room game s  in 
  rm.description

let room_name room =
  room.name

let room_to_visit game curr s = 
  if s = "forward" then (next_room game curr)
  else if s = "back" then (prev_room game curr)
  else raise (UnknownMovement s)
