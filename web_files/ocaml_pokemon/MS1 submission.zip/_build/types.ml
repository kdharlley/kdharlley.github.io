(* extra data stores what is most effective against pokemno *)
type elemtype = 
  |Normal
  |Fire
  |Water
  |Grass
  |Electric
  |Ice
  |Fighting
  |Poison

let type_to_int t =
  match t with
  |Normal -> 0
  |Fire -> 1
  |Water -> 2
  |Grass -> 3
  |Electric -> 4
  |Ice -> 5
  |Fighting -> 6
  |Poison -> 7
(* failwith "Unimplementted" *)

let type_to_string t =
  match t with
  |Normal -> "normal"
  |Fire -> "fire"
  |Water -> "water"
  |Grass -> "grass"
  |Electric -> "electric"
  |Ice -> "ice"
  |Fighting -> "fighting"
  |Poison -> "poison"

let string_to_type s = 
  let s = String.lowercase_ascii s in
  if s = "fire" then Fire else
  if s = "water" then Water else
  if s = "grass" then Grass else
  if s = "normal" then Normal  else
  if s = "electric" then Electric  else
  if s = "ice" then Ice else
  if s = "fighting" then Fighting else Poison


let effecchart : float array array  = [|[|1.0;1.0;1.0;1.0;1.0;1.0;1.0;1.0;|];
                                        [|1.0;0.5;0.5;2.0;1.0;2.0;1.0;1.0|];
                                        [|1.0;2.0;0.5;0.5;1.0;1.0;1.0;1.0|];
                                        [|1.0;0.5;2.0;0.5;1.0;1.0;1.0;0.5|];
                                        [|1.0;1.0;2.0;0.5;0.5;1.0;1.0;1.0|];
                                        [|1.0;0.5;0.5;2.0;1.0;0.5;1.0;1.0|];
                                        [|2.0;1.0;1.0;1.0;1.0;2.0;1.0;0.5|];
                                        [|1.0;1.0;1.0;2.0;1.0;1.0;1.0;0.5|];
                                      |]

let effectiveness (t:elemtype) (t:elemtype) =
  Array.get (Array.get effecchart (type_to_int t)) (type_to_int t)







