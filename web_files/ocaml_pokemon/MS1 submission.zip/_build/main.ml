
open Pokemon
open Attacks
open Gameworld
open State
open Command

(** [extract_state curr_st new_st] is the state represented by the 
    command [new_st], with [curr_st] being the previous state.
    If [new_st] is [Illegal] [curr_st] is returned *)
let extract_state curr_st new_st = 
  match new_st with
  | Legal st -> st
  | Illegal -> curr_st

let rec eval_loop game pkdex atdir st =
  (* Part of loop that handles out of battle logic *)
  if in_battle st = false then (
    print_endline (room_desc game (current_room st));
    print_endline (get_description (curr_pokemon st));
    print_endline "Please enter your next move.\n";
    print_string  "> ";
    try
      match parse (read_line ()) with
      | Go s->
        let command_name = String.concat " " s in
        let new_state = go command_name game st |> extract_state st in
        if new_state = st then begin
          print_endline "It appears that was an invalid command.";
          eval_loop game pkdex atdir new_state
        end else eval_loop game pkdex atdir new_state
      | Quit -> print_endline "Thanks for playing!!"; Stdlib.exit 0
      | Battle s-> print_endline "dddd"
    with
    | Malformed -> print_endline "Invalid Command"; eval_loop game pkdex atdir st
    | Empty -> print_endline "Empty Command"; eval_loop game pkdex atdir st
    | exn -> print_endline "That is an invalid command"; eval_loop game pkdex atdir st
  )
(* Down here write in battle logic *)

let rec battle_loop game pkdex atdir st = 
  failwith "Unimplemented"


(** [play_game f] starts the adventure in file [f].
    Prints an error message if [f] is an invalid file and then prompts for a
    valid file to start*)
let rec play_game f init=
  try
    let pokedex = from_json (Yojson.Basic.from_file "pokemon.json") in
    let game = game_json (Yojson.Basic.from_file f) pokedex in
    let attack_dir = attack_dict (Yojson.Basic.from_file "attacks.json") in
    eval_loop game pokedex attack_dir init
  (* let pokemon = from_json (Yojson.Basic.from_file f) in *)
  (* () *)
  (* eval_loop adv (init_state adv) *)
  with exn -> 
    print_endline "Invalid filename, please enter a valid file";
    print_endline "Please enter the name of the pokemon game you want to load.\n";
    print_string  "> ";
    match read_line () with
    | exception End_of_file -> ()
    | file_name ->  play_game file_name init


let characters:(string list)= [] 
(** [main ()] prompts for the game to play, then starts it. *)

(** [choose_character] lets the player choose their character and creates an 
    initial state with that character*)
let choose_character f pokedex : State.t=
  print_endline "What type pokemon would you like?\n";
  print_string "> ";
  let type_chosen = read_line () in
  print_endline "Select your pokemon. Your options are: \n";
  (* print_endline type_chosen; *)
  print_endline (String.concat " " (pokemon_of_type type_chosen pokedex []));
  print_string  "> ";
  let game = game_json (Yojson.Basic.from_file f) pokedex in
  match read_line () with
  | p -> let chosen_poke = get_pokemon pokedex ( String.capitalize_ascii (String.lowercase_ascii p)) in
    let chosen_name = get_name chosen_poke in
    init_state game pokedex chosen_name
(* | exception End_of_file -> f *)
(* what if they enter an invalid name?*)

let main () =
  (* let pokedex = from_json (Yojson.Basic.from_file "pokemon.json") in
     let game = game_json (Yojson.Basic.from_file "game1.json") pokedex in
     print_string (room_desc game "room2"); *)
  let pokedex = from_json (Yojson.Basic.from_file "pokemon.json") in
  ANSITerminal.(print_string [red]
                  "\n\nWelcome to the 3110 Pokemon Battle Game engine.\n");

  print_endline "Please enter the name of the game file you want to load.\n";
  print_string  "> ";
  match read_line () with
  | exception End_of_file -> ()
  | file_name ->  let st = choose_character file_name pokedex in
    play_game file_name st

let eval_loop p s g = ()


let ()= main ()
