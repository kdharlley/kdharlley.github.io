open Types
open Yojson.Basic.Util
(* open Pokemon *)

type attack = {
  name : string;
  elemtype : elemtype;
  dmg : int;
  accuracy : int;
  description : string;
}

let attack_json json = {
  name = json |> member "ename" |> to_string;
  elemtype = json |> member "type" |> to_string |> string_to_type;
  dmg = json |> member "power" |> to_int;
  accuracy = json |> member "accuracy" |> to_int;
  description = json |> member "ename" |> to_string;
}

let parse_attacks json = json |> to_list |> List.map attack_json

module AttackMap = Map.Make (struct
    type t = string
    let compare = Stdlib.compare
  end
  )

let rec make_attack_dict a_lst attack_map =
  match a_lst with
  | [] -> attack_map
  | h::t -> make_attack_dict t AttackMap.(add h.name h attack_map)


let attack_dict json= make_attack_dict (parse_attacks json) AttackMap.empty

type t = attack AttackMap.t

open AttackMap

let get_atk a attackdict=
  let attack = find_opt a attackdict in
  match attack with
  | Some v -> v
  | None -> failwith "Attack Name not well-defined"

let attack_effect t1 t2  =
  failwith "Unimplementted"

let atk_dmg a attackdict=
  let attack = get_atk a attackdict in
  attack.dmg 
(* failwith "Unimplementted" *)

let atk_accu a attackdict  =
  let attack = get_atk a attackdict in
  attack.accuracy
(* failwith "Unimplementted" *)

let atk_desc a attackdict  =
  let attack = get_atk a attackdict in
  attack.description

(* 
let get_atk s  =
  failwith "Unimplementted" *)
